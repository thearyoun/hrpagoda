#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `code_number` varchar(25) DEFAULT NULL,
  `name_en` varchar(125) DEFAULT NULL,
  `name_kh` varchar(124) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `phone` varchar(35) DEFAULT NULL,
  `mobile` varchar(35) DEFAULT NULL,
  `address` text,
  `using_location_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (1, 'CUS-0001', 'MEAS PISEY', 'មាស ពិសី', 'sokry@gmail.com', '010 596 900', '010 596 900', 'PP', 1, 1, '2015-06-29 10:09:30', '2015-06-29 10:09:30');
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (2, 'CUS-0002', 'PEL SREYLAEN', 'ប៉ិល ស្រីឡែន', '', '012352233', '', 'PP', 1, 1, '2015-06-29 10:10:21', '2015-06-29 10:10:21');
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (3, 'CUS-0003', 'SOR LAISIM', 'សរ ឡៃស៊ីម', '', '010 22 56 21', '', 'PP', 1, 1, '2015-06-29 10:11:12', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (4, 'CUS-0004', 'NGET CHENDA', 'ង៉ែត ចិន្តា', '', '012 756 987', '', 'PP', 1, 1, '2015-06-29 10:12:14', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (5, 'CUS-0005', 'NEANG PHIN', 'នាង ភីន', '', '01235 45 56', '', 'PP', 1, 1, '2015-06-29 10:14:01', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (6, 'CUS-0006', 'TUN SOPHA', 'ទន់ សុផា', '', '012 625 551', '', 'PP', 1, 1, '2015-06-29 10:14:48', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (7, 'CUS-0007', 'PECH VANNSAREUON', 'ប៉ិច វណ្ណសារឿន', '', '012 245 315', '', 'PP', 1, 1, '2015-06-29 10:16:03', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (8, 'CUS-0008', 'AIEM VANG', 'អៀម វ៉ាង', '', '0125 545 21', '', 'PP', 1, 1, '2015-06-29 10:16:42', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (9, 'CUS-0009', 'HEM CHHENGLY', 'ហែម ឆេងលី', '', '015 255 244', '', 'PP', 1, 1, '2015-06-29 10:17:26', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (10, 'CUS-00010', 'KIM CHANTHORN', 'គឹម ចាន់ថន', '', '012 355 541', '', 'PP', 1, 1, '2015-06-29 10:18:11', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (11, 'CUS-00011', 'HOUT TIT', 'ហួត ទិត', '', '012 848 574', '', 'PP', 1, 1, '2015-06-29 10:18:50', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (12, 'CUS-00012', 'NORNG THA', 'នង ថា', '', '012 475 511​ ', '', 'pp', 1, 1, '2015-06-29 10:19:36', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (13, 'CUS-00013', 'NIN SAMAI', 'និន សម័យ', '', '012 475 511​ ', '', 'PP', 1, 1, '2015-06-29 10:20:10', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (14, 'CUS-00014', 'TOUCH SOKHY', 'ទូច សុខឃី', '', '012 654 325', '', 'pp', 1, 1, '2015-06-29 10:21:03', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (15, 'CUS-00015', 'SAN SEOUN', 'សាន សឿន', '', '012​5455​5', '', 'pp', 0, 1, '2015-06-29 10:21:42', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (16, 'CUS-00016', 'TUN SINARITH', 'ទន់ ស៊ីណារឹទ្ធ', '', '015 252 558', '', '', 0, 1, '2015-06-29 10:22:37', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (17, 'CUS-00017', 'YORN LYNA', 'យ៉ន លីណា', '', '015 365 245', '', 'PP', 1, 1, '2015-06-29 10:23:27', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (18, 'CUS-00018', 'SEOUNG SAYEANG', 'ស៊ឹង សៃយាង', '', '012 545 255', '', 'PP', 0, 1, '2015-06-29 10:24:20', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (19, 'CUS-00019', 'SOEUNG THA', 'ស៊ឹង ថា', '', '012​5455​5', '', 'PP', 1, 1, '2015-06-29 10:25:02', NULL);
INSERT INTO customers (`customer_id`, `code_number`, `name_en`, `name_kh`, `email`, `phone`, `mobile`, `address`, `using_location_id`, `status`, `created_date`, `modified_date`) VALUES (20, 'CUS-00020', 'TANG SUN', 'តាំង ស៊ុន', '', '012 654 351', '', 'pp', 1, 1, '2015-06-29 10:29:20', NULL);


#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS departments;

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(125) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO departments (`department_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (1, 'CREDIT MANAGER', 'CREDIT OFFICER', 1, '2015-06-29 11:15:52', '2015-03-16 22:15:26');


#
# TABLE STRUCTURE FOR: employees
#

DROP TABLE IF EXISTS employees;

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(75) NOT NULL,
  `username_kh` varchar(75) DEFAULT NULL,
  `username_en` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `address` text,
  `using_location_id` int(11) DEFAULT NULL,
  `using_department_id` int(11) DEFAULT NULL,
  `profile_picture` varchar(125) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO employees (`employee_id`, `employee_code`, `username_kh`, `username_en`, `email`, `phone`, `address`, `using_location_id`, `using_department_id`, `profile_picture`, `status`, `created_date`, `modified_date`) VALUES (1, 'CLV-0001', 'ឡេង ឡង់ដា', 'LENG LANDA', 'lenglanda40@gmail.com', '096 631 2714/070 97 36 25', 'pp', 1, 1, '', 1, '2015-06-30 23:02:17', NULL);


#
# TABLE STRUCTURE FOR: holiday_details
#

DROP TABLE IF EXISTS holiday_details;

CREATE TABLE `holiday_details` (
  `holiday_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_holiday_id` int(11) NOT NULL,
  `holiday_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`holiday_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (1, 1, '2015-01-01', 1, '0000-00-00 00:00:00', '2015-04-12 07:28:09');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (2, 2, '2015-01-07', 1, '0000-00-00 00:00:00', '2015-04-12 07:28:29');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (3, 3, '2015-02-14', 1, '0000-00-00 00:00:00', '2015-04-12 07:29:46');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (4, 4, '2015-03-08', 1, '0000-00-00 00:00:00', '2015-04-12 07:29:46');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (5, 5, '2015-04-14', 1, '0000-00-00 00:00:00', '2015-04-12 07:30:32');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (6, 5, '2015-04-15', 1, '0000-00-00 00:00:00', '2015-04-12 07:30:32');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (7, 5, '2015-04-16', 1, '0000-00-00 00:00:00', '2015-04-12 07:30:32');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (8, 6, '2015-05-01', 1, '0000-00-00 00:00:00', '2015-04-12 07:31:56');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (9, 7, '2015-05-13', 1, '0000-00-00 00:00:00', '2015-04-12 07:31:56');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (10, 7, '2015-05-14', 1, '0000-00-00 00:00:00', '2015-04-12 07:31:56');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (11, 7, '2015-05-15', 1, '0000-00-00 00:00:00', '2015-04-12 07:31:56');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (15, 8, '2015-04-20', 1, '2015-04-20 20:07:20', '2015-04-20 20:07:20');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (16, 8, '2015-04-21', 1, '2015-04-20 20:07:20', '2015-04-20 20:07:20');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (17, 9, '2015-05-13', 1, '2015-05-13 09:21:32', '2015-05-17 12:30:17');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (18, 9, '2015-05-14', 1, '2015-05-13 09:21:32', '2015-05-17 12:30:19');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (19, 9, '2015-05-15', 1, '2015-05-13 09:21:32', '2015-05-17 12:30:23');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (20, 10, '2015-06-01', 1, '2015-06-24 19:31:02', '2015-06-24 19:31:02');
INSERT INTO holiday_details (`holiday_detail_id`, `using_holiday_id`, `holiday_date`, `status`, `created_date`, `modified_date`) VALUES (21, 10, '2015-06-02', 1, '2015-06-24 19:31:02', '2015-06-24 19:31:02');


#
# TABLE STRUCTURE FOR: holidays
#

DROP TABLE IF EXISTS holidays;

CREATE TABLE `holidays` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(125) NOT NULL,
  `description` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (1, 'International New Year Day', '', '2015-01-01', '2015-01-01', 1, '2015-04-12 00:00:00', '2015-04-12 07:18:21');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (2, 'Victory over Genocidal Regime Day', '', '2014-01-07', '2014-01-07', 1, '0000-00-00 00:00:00', '2015-04-12 07:19:35');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (3, 'Meak Bochea Day', '', '2014-02-14', '2014-02-14', 1, '0000-00-00 00:00:00', '2015-04-12 07:19:35');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (4, 'International Women\'s Day', '', '2014-03-08', '2014-03-08', 1, '0000-00-00 00:00:00', '2015-04-12 07:21:05');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (5, 'Khmer New Year Day', '', '2014-04-14', '2014-04-16', 1, '0000-00-00 00:00:00', '2015-04-12 07:21:05');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (6, 'International Labor Day', '', '2014-05-01', '2014-05-01', 1, '0000-00-00 00:00:00', '2015-04-12 07:22:29');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (7, 'King\'s Birthday, Norodom Sihamoni', '', '2014-05-13', '2014-05-15', 1, '0000-00-00 00:00:00', '2015-04-12 07:22:29');
INSERT INTO holidays (`holiday_id`, `name`, `description`, `from_date`, `to_date`, `status`, `created_date`, `modified_date`) VALUES (8, 'Test Day', 'just desc', '2015-04-20', '2015-04-21', 1, '2015-04-20 20:07:20', '2015-04-20 20:07:20');


#
# TABLE STRUCTURE FOR: insurances
#

DROP TABLE IF EXISTS insurances;

CREATE TABLE `insurances` (
  `insurance_id` int(11) NOT NULL AUTO_INCREMENT,
  `code_number` varchar(25) DEFAULT NULL,
  `name_en` varchar(125) DEFAULT NULL,
  `name_kh` varchar(124) DEFAULT NULL,
  `phone` varchar(35) DEFAULT NULL,
  `address` text,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`insurance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO insurances (`insurance_id`, `code_number`, `name_en`, `name_kh`, `phone`, `address`, `status`, `created_date`, `modified_date`) VALUES (1, 'INS-0001', 'sokly.khon', 'sokly.khon', '0939382928', '', 1, '2015-06-16 19:56:40', NULL);


#
# TABLE STRUCTURE FOR: interest_types
#

DROP TABLE IF EXISTS interest_types;

CREATE TABLE `interest_types` (
  `interest_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`interest_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO interest_types (`interest_type_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (1, 'FLAT', 'Laon with interest fix', 1, '2015-03-25 22:26:57', '2015-03-18 18:20:42');
INSERT INTO interest_types (`interest_type_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (2, 'DECLINE', 'Interest and loan discrease', 1, '2015-03-25 22:26:38', '2015-03-18 18:21:52');
INSERT INTO interest_types (`interest_type_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (3, 'BARLOON', 'Interest only', 1, '2015-03-25 22:26:20', '2015-03-18 18:22:28');


#
# TABLE STRUCTURE FOR: loan_payments
#

DROP TABLE IF EXISTS loan_payments;

CREATE TABLE `loan_payments` (
  `loan_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_loan_id` int(11) NOT NULL,
  `using_employee_id` int(11) NOT NULL,
  `using_customer_id` int(11) NOT NULL,
  `amount_en` float NOT NULL,
  `amount_kh` float NOT NULL,
  `payment_date` date NOT NULL,
  `payment_note` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `principle_amount_interest` float DEFAULT NULL,
  PRIMARY KEY (`loan_payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (1, 2, 1, 1, '50', '0', '2015-06-24', '', 1, '2015-06-23 17:11:28', '2015-06-23 17:11:28', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (2, 1, 1, 1, '120', '0', '2015-06-24', '', 1, '2015-06-23 17:24:21', '2015-06-23 17:24:21', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (3, 1, 1, 1, '1880', '0', '2015-06-24', '', 1, '2015-06-23 17:43:47', '2015-06-23 17:43:47', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (4, 3, 1, 2, '11.6', '0', '2015-06-28', '', 1, '2015-06-28 13:08:17', '2015-06-28 13:08:17', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (5, 18, 1, 11, '275', '0', '2015-06-29', '', 1, '2015-06-29 06:21:19', '2015-06-29 06:21:19', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (6, 18, 1, 11, '75', '0', '2015-06-29', '', 1, '2015-06-29 06:22:04', '2015-06-29 06:22:04', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (7, 4, 1, 8, '25.36', '0', '2015-06-29', '', 1, '2015-06-29 06:24:52', '2015-06-29 06:24:52', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (8, 5, 1, 9, '137.2', '0', '2015-06-29', '', 1, '2015-06-29 06:25:32', '2015-06-29 06:25:32', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (9, 6, 1, 10, '152.16', '0', '2015-06-29', '', 1, '2015-06-29 06:26:11', '2015-06-29 06:26:11', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (10, 7, 1, 5, '135', '0', '2015-06-29', '', 1, '2015-06-29 06:26:39', '2015-06-29 06:26:39', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (11, 8, 1, 4, '177.5', '0', '2015-06-29', '', 1, '2015-06-29 06:27:25', '2015-06-29 06:27:25', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (12, 9, 1, 13, '12', '0', '2015-06-29', '', 1, '2015-06-29 06:27:55', '2015-06-29 06:27:55', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (13, 10, 1, 12, '35.5', '0', '2015-06-29', '', 1, '2015-06-29 06:28:38', '2015-06-29 06:28:38', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (14, 21, 1, 6, '74', '0', '2015-06-29', '', 1, '2015-06-29 06:29:22', '2015-06-29 06:29:22', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (15, 19, 1, 14, '85.56', '0', '2015-06-29', '', 1, '2015-06-29 06:29:57', '2015-06-29 06:29:57', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (16, 16, 1, 18, '59.88', '0', '2015-06-29', '', 1, '2015-06-29 06:30:40', '2015-06-29 06:30:40', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (17, 15, 1, 19, '37.4', '0', '2015-06-29', '', 1, '2015-06-29 06:31:12', '2015-06-29 06:31:12', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (18, 11, 1, 7, '59.76', '0', '2015-06-29', '', 1, '2015-06-29 08:50:11', '2015-06-29 08:50:11', NULL);
INSERT INTO loan_payments (`loan_payment_id`, `using_loan_id`, `using_employee_id`, `using_customer_id`, `amount_en`, `amount_kh`, `payment_date`, `payment_note`, `status`, `created_date`, `modified_date`, `principle_amount_interest`) VALUES (19, 14, 1, 15, '29', '0', '2015-06-29', '', 1, '2015-06-29 08:51:00', '2015-06-29 08:51:00', NULL);


#
# TABLE STRUCTURE FOR: loan_schedule_payment_detail
#

DROP TABLE IF EXISTS loan_schedule_payment_detail;

CREATE TABLE `loan_schedule_payment_detail` (
  `loan_schedule_payment_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_loan_id` int(11) NOT NULL,
  `principle_paid_amount` float NOT NULL,
  `times` int(11) DEFAULT NULL,
  `payment_amount` float NOT NULL,
  `payment_date` date NOT NULL,
  `is_paid` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`loan_schedule_payment_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=377 DEFAULT CHARSET=utf8;

INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (1, 1, '0', 1, '0', '2015-06-05', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:24:22');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (2, 1, '0', 2, '0', '2015-06-06', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (3, 1, '0', 3, '0', '2015-06-08', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (4, 1, '0', 4, '0', '2015-06-09', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (5, 1, '0', 5, '0', '2015-06-10', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (6, 1, '0', 6, '0', '2015-06-11', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (7, 1, '0', 7, '0', '2015-06-12', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (8, 1, '0', 8, '0', '2015-06-13', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (9, 1, '0', 9, '0', '2015-06-15', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (10, 1, '0', 10, '0', '2015-06-16', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (11, 1, '0', 11, '0', '2015-06-17', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (12, 1, '0', 12, '0', '2015-06-18', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (13, 1, '0', 13, '0', '2015-06-19', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (14, 1, '0', 14, '0', '2015-06-20', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (15, 1, '0', 15, '0', '2015-06-22', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (16, 1, '0', 16, '0', '2015-06-23', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (17, 1, '0', 17, '0', '2015-06-24', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (18, 1, '0', 18, '0', '2015-06-25', 1, 1, '2015-06-19 18:36:28', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (19, 1, '0', 19, '0', '2015-06-26', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (20, 1, '0', 20, '0', '2015-06-27', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (21, 1, '0', 21, '0', '2015-06-29', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (22, 1, '0', 22, '0', '2015-06-30', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (23, 1, '0', 23, '0', '2015-07-01', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (24, 1, '0', 24, '0', '2015-07-02', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (25, 1, '0', 25, '0', '2015-07-03', 1, 1, '2015-06-19 18:36:29', '2015-06-24 00:43:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (26, 2, '0', 1, '0', '2015-06-18', 1, 1, '2015-06-19 18:39:48', '2015-06-24 00:11:29');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (27, 2, '0', 2, '0', '2015-06-19', 1, 1, '2015-06-19 18:39:48', '2015-06-24 00:11:29');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (28, 2, '0', 3, '0', '2015-06-20', 1, 1, '2015-06-19 18:39:48', '2015-06-24 00:11:29');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (29, 2, '0', 4, '2', '2015-06-22', 0, 1, '2015-06-19 18:39:48', '2015-06-24 00:11:29');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (30, 2, '0', 5, '13', '2015-06-23', 0, 1, '2015-06-19 18:39:48', '2015-06-19 18:39:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (31, 2, '0', 6, '13', '2015-06-24', 0, 1, '2015-06-19 18:39:48', '2015-06-19 18:39:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (32, 2, '0', 7, '13', '2015-06-25', 0, 1, '2015-06-19 18:39:48', '2015-06-19 18:39:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (33, 2, '0', 8, '13', '2015-06-26', 0, 1, '2015-06-19 18:39:48', '2015-06-19 18:39:48');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (34, 2, '0', 9, '13', '2015-06-27', 0, 1, '2015-06-19 18:39:49', '2015-06-19 18:39:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (35, 2, '0', 10, '13', '2015-06-29', 0, 1, '2015-06-19 18:39:49', '2015-06-19 18:39:49');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (36, 3, '0', 1, '0', '2015-06-23', 1, 1, '2015-06-28 20:04:52', '2015-06-28 20:08:17');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (37, 3, '0', 2, '0', '2015-06-24', 1, 1, '2015-06-28 20:04:52', '2015-06-28 20:08:17');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (38, 3, '0', 3, '5.8', '2015-06-25', 0, 1, '2015-06-28 20:04:52', '2015-06-28 20:04:52');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (39, 3, '0', 4, '5.8', '2015-06-26', 0, 1, '2015-06-28 20:04:52', '2015-06-28 20:04:52');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (40, 3, '0', 5, '5.8', '2015-06-27', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (41, 3, '0', 6, '5.8', '2015-06-29', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (42, 3, '0', 7, '5.8', '2015-06-30', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (43, 3, '0', 8, '5.8', '2015-07-01', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (44, 3, '0', 9, '5.8', '2015-07-02', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (45, 3, '0', 10, '5.8', '2015-07-03', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (46, 3, '0', 11, '5.8', '2015-07-04', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (47, 3, '0', 12, '5.8', '2015-07-06', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (48, 3, '0', 13, '5.8', '2015-07-07', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (49, 3, '0', 14, '5.8', '2015-07-08', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (50, 3, '0', 15, '5.8', '2015-07-09', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (51, 3, '0', 16, '5.8', '2015-07-10', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (52, 3, '0', 17, '5.8', '2015-07-11', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (53, 3, '0', 18, '5.8', '2015-07-13', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (54, 3, '0', 19, '5.8', '2015-07-14', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (55, 3, '0', 20, '5.8', '2015-07-15', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (56, 3, '0', 21, '5.8', '2015-07-16', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (57, 3, '0', 22, '5.8', '2015-07-17', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (58, 3, '0', 23, '5.8', '2015-07-18', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (59, 3, '0', 24, '5.8', '2015-07-20', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (60, 3, '0', 25, '5.8', '2015-07-21', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (61, 3, '0', 26, '5.8', '2015-07-22', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (62, 3, '0', 27, '5.8', '2015-07-23', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (63, 3, '0', 28, '5.8', '2015-07-24', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (64, 3, '0', 29, '5.8', '2015-07-25', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (65, 3, '0', 30, '5.8', '2015-07-27', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (66, 3, '0', 31, '5.8', '2015-07-28', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (67, 3, '0', 32, '5.8', '2015-07-29', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (68, 3, '0', 33, '5.8', '2015-07-30', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (69, 3, '0', 34, '5.8', '2015-07-31', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (70, 3, '0', 35, '5.8', '2015-08-01', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (71, 3, '0', 36, '5.8', '2015-08-03', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (72, 3, '0', 37, '5.8', '2015-08-04', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (73, 3, '0', 38, '5.8', '2015-08-05', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (74, 3, '0', 39, '5.8', '2015-08-06', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (75, 3, '0', 40, '5.8', '2015-08-07', 0, 1, '2015-06-28 20:04:53', '2015-06-28 20:04:53');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (76, 4, '0', 1, '0', '2015-06-23', 1, 1, '2015-06-29 11:33:59', '2015-06-29 13:24:52');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (77, 4, '0', 2, '25.36', '2015-06-30', 0, 1, '2015-06-29 11:33:59', '2015-06-29 11:33:59');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (78, 4, '0', 3, '25.36', '2015-07-07', 0, 1, '2015-06-29 11:33:59', '2015-06-29 11:33:59');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (79, 4, '0', 4, '25.36', '2015-07-14', 0, 1, '2015-06-29 11:33:59', '2015-06-29 11:33:59');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (80, 4, '0', 5, '25.36', '2015-07-21', 0, 1, '2015-06-29 11:33:59', '2015-06-29 11:33:59');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (81, 4, '0', 6, '25.36', '2015-07-28', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (82, 4, '0', 7, '25.36', '2015-08-04', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (83, 4, '0', 8, '25.36', '2015-08-11', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (84, 4, '0', 9, '25.36', '2015-08-18', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (85, 4, '0', 10, '25.36', '2015-08-25', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (86, 4, '0', 11, '25.36', '2015-09-01', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (87, 4, '0', 12, '25.36', '2015-09-08', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (88, 4, '0', 13, '25.36', '2015-09-15', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (89, 4, '0', 14, '25.36', '2015-09-22', 0, 1, '2015-06-29 11:34:00', '2015-06-29 11:34:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (90, 5, '0', 1, '0', '2015-06-03', 1, 1, '2015-06-29 12:23:13', '2015-06-29 13:25:32');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (91, 5, '0', 2, '0', '2015-06-09', 1, 1, '2015-06-29 12:23:13', '2015-06-29 13:25:32');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (92, 5, '0', 3, '0', '2015-06-16', 1, 1, '2015-06-29 12:23:13', '2015-06-29 13:25:32');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (93, 5, '0', 4, '0', '2015-06-23', 1, 1, '2015-06-29 12:23:13', '2015-06-29 13:25:32');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (94, 5, '0', 5, '34.3', '2015-06-30', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (95, 5, '0', 6, '34.3', '2015-07-07', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (96, 5, '0', 7, '34.3', '2015-07-14', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (97, 5, '0', 8, '34.3', '2015-07-21', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (98, 5, '0', 9, '34.3', '2015-07-28', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (99, 5, '0', 10, '34.3', '2015-08-04', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (100, 5, '0', 11, '34.3', '2015-08-11', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (101, 5, '0', 12, '34.3', '2015-08-18', 0, 1, '2015-06-29 12:23:13', '2015-06-29 12:23:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (102, 6, '0', 1, '0', '2015-06-03', 1, 1, '2015-06-29 12:25:17', '2015-06-29 13:26:11');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (103, 6, '0', 2, '0', '2015-06-09', 1, 1, '2015-06-29 12:25:18', '2015-06-29 13:26:11');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (104, 6, '0', 3, '0', '2015-06-16', 1, 1, '2015-06-29 12:25:18', '2015-06-29 13:26:11');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (105, 6, '0', 4, '0', '2015-06-23', 1, 1, '2015-06-29 12:25:18', '2015-06-29 13:26:11');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (106, 6, '0', 5, '38.04', '2015-06-30', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (107, 6, '0', 6, '38.04', '2015-07-07', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (108, 6, '0', 7, '38.04', '2015-07-14', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (109, 6, '0', 8, '38.04', '2015-07-21', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (110, 6, '0', 9, '38.04', '2015-07-28', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (111, 6, '0', 10, '38.04', '2015-08-04', 0, 1, '2015-06-29 12:25:18', '2015-06-29 12:25:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (112, 7, '0', 1, '0', '2015-05-26', 1, 1, '2015-06-29 12:26:59', '2015-06-29 13:26:39');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (113, 7, '0', 2, '0', '2015-06-03', 1, 1, '2015-06-29 12:27:00', '2015-06-29 13:26:39');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (114, 7, '0', 3, '0', '2015-06-09', 1, 1, '2015-06-29 12:27:00', '2015-06-29 13:26:39');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (115, 7, '0', 4, '0', '2015-06-16', 1, 1, '2015-06-29 12:27:00', '2015-06-29 13:26:39');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (116, 7, '0', 5, '0', '2015-06-23', 1, 1, '2015-06-29 12:27:00', '2015-06-29 13:26:39');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (117, 7, '0', 6, '27', '2015-06-30', 0, 1, '2015-06-29 12:27:00', '2015-06-29 12:27:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (118, 7, '0', 7, '27', '2015-07-07', 0, 1, '2015-06-29 12:27:00', '2015-06-29 12:27:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (119, 7, '0', 8, '27', '2015-07-14', 0, 1, '2015-06-29 12:27:00', '2015-06-29 12:27:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (120, 7, '0', 9, '27', '2015-07-21', 0, 1, '2015-06-29 12:27:00', '2015-06-29 12:27:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (121, 7, '0', 10, '27', '2015-07-28', 0, 1, '2015-06-29 12:27:00', '2015-06-29 12:27:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (122, 8, '0', 1, '0', '2015-05-26', 1, 1, '2015-06-29 12:27:53', '2015-06-29 13:27:25');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (123, 8, '0', 2, '0', '2015-06-03', 1, 1, '2015-06-29 12:27:54', '2015-06-29 13:27:25');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (124, 8, '0', 3, '0', '2015-06-09', 1, 1, '2015-06-29 12:27:54', '2015-06-29 13:27:25');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (125, 8, '0', 4, '0', '2015-06-16', 1, 1, '2015-06-29 12:27:54', '2015-06-29 13:27:25');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (126, 8, '0', 5, '0', '2015-06-23', 1, 1, '2015-06-29 12:27:54', '2015-06-29 13:27:25');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (127, 8, '0', 6, '35.5', '2015-06-30', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (128, 8, '0', 7, '35.5', '2015-07-07', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (129, 8, '0', 8, '35.5', '2015-07-14', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (130, 8, '0', 9, '35.5', '2015-07-21', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (131, 8, '0', 10, '35.5', '2015-07-28', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (132, 8, '0', 11, '35.5', '2015-08-04', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (133, 8, '0', 12, '35.5', '2015-08-11', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (134, 8, '0', 13, '35.5', '2015-08-18', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (135, 8, '0', 14, '35.5', '2015-08-25', 0, 1, '2015-06-29 12:27:54', '2015-06-29 12:27:54');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (136, 9, '0', 1, '0', '2015-06-23', 1, 1, '2015-06-29 12:29:40', '2015-06-29 13:27:55');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (137, 9, '0', 2, '12', '2015-06-30', 0, 1, '2015-06-29 12:29:40', '2015-06-29 12:29:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (138, 9, '0', 3, '12', '2015-07-07', 0, 1, '2015-06-29 12:29:40', '2015-06-29 12:29:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (139, 9, '0', 4, '12', '2015-07-14', 0, 1, '2015-06-29 12:29:40', '2015-06-29 12:29:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (140, 9, '0', 5, '12', '2015-07-21', 0, 1, '2015-06-29 12:29:40', '2015-06-29 12:29:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (141, 10, '0', 1, '0', '2015-06-16', 1, 1, '2015-06-29 12:36:18', '2015-06-29 13:28:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (142, 10, '0', 2, '0', '2015-06-23', 1, 1, '2015-06-29 12:36:18', '2015-06-29 13:28:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (143, 10, '0', 3, '17.75', '2015-06-30', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (144, 10, '0', 4, '17.75', '2015-07-07', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (145, 10, '0', 5, '17.75', '2015-07-14', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (146, 10, '0', 6, '17.75', '2015-07-21', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (147, 10, '0', 7, '17.75', '2015-07-28', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (148, 10, '0', 8, '17.75', '2015-08-04', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (149, 10, '0', 9, '17.75', '2015-08-11', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (150, 10, '0', 10, '17.75', '2015-08-18', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (151, 10, '0', 11, '17.75', '2015-08-25', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (152, 10, '0', 12, '17.75', '2015-09-01', 0, 1, '2015-06-29 12:36:18', '2015-06-29 12:36:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (153, 11, '0', 1, '0', '2015-06-20', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:11');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (154, 11, '0', 2, '0', '2015-06-22', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (155, 11, '0', 3, '0', '2015-06-23', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (156, 11, '0', 4, '0', '2015-06-24', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (157, 11, '0', 5, '0', '2015-06-25', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (158, 11, '0', 6, '0', '2015-06-26', 1, 1, '2015-06-29 12:54:59', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (159, 11, '0', 7, '0', '2015-06-27', 1, 1, '2015-06-29 12:55:00', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (160, 11, '0', 8, '0', '2015-06-29', 1, 1, '2015-06-29 12:55:00', '2015-06-29 15:50:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (161, 11, '0', 9, '7.47', '2015-06-30', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (162, 11, '0', 10, '7.47', '2015-07-01', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (163, 11, '0', 11, '7.47', '2015-07-02', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (164, 11, '0', 12, '7.47', '2015-07-03', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (165, 11, '0', 13, '7.47', '2015-07-04', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (166, 11, '0', 14, '7.47', '2015-07-06', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (167, 11, '0', 15, '7.47', '2015-07-07', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (168, 11, '0', 16, '7.47', '2015-07-08', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (169, 11, '0', 17, '7.47', '2015-07-09', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (170, 11, '0', 18, '7.47', '2015-07-10', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (171, 11, '0', 19, '7.47', '2015-07-11', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (172, 11, '0', 20, '7.47', '2015-07-13', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (173, 11, '0', 21, '7.47', '2015-07-14', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (174, 11, '0', 22, '7.47', '2015-07-15', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (175, 11, '0', 23, '7.47', '2015-07-16', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (176, 11, '0', 24, '7.47', '2015-07-17', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (177, 11, '0', 25, '7.47', '2015-07-18', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (178, 11, '0', 26, '7.47', '2015-07-20', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (179, 11, '0', 27, '7.47', '2015-07-21', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (180, 11, '0', 28, '7.47', '2015-07-22', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (181, 11, '0', 29, '7.47', '2015-07-23', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (182, 11, '0', 30, '7.47', '2015-07-24', 0, 1, '2015-06-29 12:55:00', '2015-06-29 12:55:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (183, 12, '0', 1, '12', '2015-06-30', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (184, 12, '0', 2, '12', '2015-07-07', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (185, 12, '0', 3, '12', '2015-07-14', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (186, 12, '0', 4, '12', '2015-07-21', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (187, 12, '0', 5, '12', '2015-07-28', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (188, 12, '0', 6, '12', '2015-08-04', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (189, 12, '0', 7, '12', '2015-08-11', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (190, 12, '0', 8, '412', '2015-08-18', 0, 1, '2015-06-29 12:56:47', '2015-06-29 12:56:47');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (191, 13, '0', 1, '62', '2015-06-30', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (192, 13, '0', 2, '62', '2015-07-07', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (193, 13, '0', 3, '62', '2015-07-14', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (194, 13, '0', 4, '62', '2015-07-21', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (195, 13, '0', 5, '62', '2015-07-28', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (196, 13, '0', 6, '62', '2015-08-04', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (197, 13, '0', 7, '62', '2015-08-11', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (198, 13, '0', 8, '62', '2015-08-18', 0, 1, '2015-06-29 12:57:38', '2015-06-29 12:57:38');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (199, 14, '0', 1, '0', '2015-06-23', 1, 1, '2015-06-29 12:58:55', '2015-06-29 15:51:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (200, 14, '0', 2, '0', '2015-06-24', 1, 1, '2015-06-29 12:58:55', '2015-06-29 15:51:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (201, 14, '0', 3, '0', '2015-06-25', 1, 1, '2015-06-29 12:58:55', '2015-06-29 15:51:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (202, 14, '0', 4, '0', '2015-06-26', 1, 1, '2015-06-29 12:58:55', '2015-06-29 15:51:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (203, 14, '0', 5, '0.00000000000000177636', '2015-06-27', 0, 1, '2015-06-29 12:58:55', '2015-06-29 15:51:00');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (204, 14, '0', 6, '5.8', '2015-06-29', 0, 1, '2015-06-29 12:58:55', '2015-06-29 12:58:55');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (205, 14, '0', 7, '5.8', '2015-06-30', 0, 1, '2015-06-29 12:58:55', '2015-06-29 12:58:55');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (206, 14, '0', 8, '5.8', '2015-07-01', 0, 1, '2015-06-29 12:58:55', '2015-06-29 12:58:55');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (207, 14, '0', 9, '5.8', '2015-07-02', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (208, 14, '0', 10, '5.8', '2015-07-03', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (209, 14, '0', 11, '5.8', '2015-07-04', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (210, 14, '0', 12, '5.8', '2015-07-06', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (211, 14, '0', 13, '5.8', '2015-07-07', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (212, 14, '0', 14, '5.8', '2015-07-08', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (213, 14, '0', 15, '5.8', '2015-07-09', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (214, 14, '0', 16, '5.8', '2015-07-10', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (215, 14, '0', 17, '5.8', '2015-07-11', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (216, 14, '0', 18, '5.8', '2015-07-13', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (217, 14, '0', 19, '5.8', '2015-07-14', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (218, 14, '0', 20, '5.8', '2015-07-15', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (219, 14, '0', 21, '5.8', '2015-07-16', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (220, 14, '0', 22, '5.8', '2015-07-17', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (221, 14, '0', 23, '5.8', '2015-07-18', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (222, 14, '0', 24, '5.8', '2015-07-20', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (223, 14, '0', 25, '5.8', '2015-07-21', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (224, 14, '0', 26, '5.8', '2015-07-22', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (225, 14, '0', 27, '5.8', '2015-07-23', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (226, 14, '0', 28, '5.8', '2015-07-24', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (227, 14, '0', 29, '5.8', '2015-07-25', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (228, 14, '0', 30, '5.8', '2015-07-27', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (229, 14, '0', 31, '5.8', '2015-07-28', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (230, 14, '0', 32, '5.8', '2015-07-29', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (231, 14, '0', 33, '5.8', '2015-07-30', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (232, 14, '0', 34, '5.8', '2015-07-31', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (233, 14, '0', 35, '5.8', '2015-08-01', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (234, 14, '0', 36, '5.8', '2015-08-03', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (235, 14, '0', 37, '5.8', '2015-08-04', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (236, 14, '0', 38, '5.8', '2015-08-05', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (237, 14, '0', 39, '5.8', '2015-08-06', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (238, 14, '0', 40, '5.8', '2015-08-07', 0, 1, '2015-06-29 12:58:56', '2015-06-29 12:58:56');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (239, 15, '0', 1, '0', '2015-06-16', 1, 1, '2015-06-29 13:01:30', '2015-06-29 13:31:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (240, 15, '0', 2, '0', '2015-06-23', 1, 1, '2015-06-29 13:01:30', '2015-06-29 13:31:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (241, 15, '0', 3, '18.7', '2015-06-30', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (242, 15, '0', 4, '18.7', '2015-07-07', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (243, 15, '0', 5, '18.7', '2015-07-14', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (244, 15, '0', 6, '18.7', '2015-07-21', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (245, 15, '0', 7, '18.7', '2015-07-28', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (246, 15, '0', 8, '18.7', '2015-08-04', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (247, 15, '0', 9, '18.7', '2015-08-11', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (248, 15, '0', 10, '18.7', '2015-08-18', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (249, 15, '0', 11, '18.7', '2015-08-25', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (250, 15, '0', 12, '18.7', '2015-09-01', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (251, 15, '0', 13, '18.7', '2015-09-08', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (252, 15, '0', 14, '18.7', '2015-09-15', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (253, 15, '0', 15, '18.7', '2015-09-22', 0, 1, '2015-06-29 13:01:30', '2015-06-29 13:01:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (254, 15, '0', 16, '18.7', '2015-09-29', 0, 1, '2015-06-29 13:01:31', '2015-06-29 13:01:31');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (255, 16, '0', 1, '0', '2015-06-16', 1, 1, '2015-06-29 13:02:34', '2015-06-29 13:30:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (256, 16, '0', 2, '0', '2015-06-23', 1, 1, '2015-06-29 13:02:34', '2015-06-29 13:30:40');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (257, 16, '0', 3, '29.94', '2015-06-30', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (258, 16, '0', 4, '29.94', '2015-07-07', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (259, 16, '0', 5, '29.94', '2015-07-14', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (260, 16, '0', 6, '29.94', '2015-07-21', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (261, 16, '0', 7, '29.94', '2015-07-28', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (262, 16, '0', 8, '29.94', '2015-08-04', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (263, 16, '0', 9, '29.94', '2015-08-11', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (264, 16, '0', 10, '29.94', '2015-08-18', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (265, 16, '0', 11, '29.94', '2015-08-25', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (266, 16, '0', 12, '29.94', '2015-09-01', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (267, 16, '0', 13, '29.94', '2015-09-08', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (268, 16, '0', 14, '29.94', '2015-09-15', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (269, 16, '0', 15, '29.94', '2015-09-22', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (270, 16, '0', 16, '29.94', '2015-09-29', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (271, 16, '0', 17, '29.94', '2015-10-06', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (272, 16, '0', 18, '29.94', '2015-10-13', 0, 1, '2015-06-29 13:02:34', '2015-06-29 13:02:34');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (273, 17, '0', 1, '30.43', '2015-06-30', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (274, 17, '0', 2, '30.43', '2015-07-07', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (275, 17, '0', 3, '30.43', '2015-07-14', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (276, 17, '0', 4, '30.43', '2015-07-21', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (277, 17, '0', 5, '30.43', '2015-07-28', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (278, 17, '0', 6, '30.43', '2015-08-04', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (279, 17, '0', 7, '30.43', '2015-08-11', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (280, 17, '0', 8, '30.43', '2015-08-18', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (281, 17, '0', 9, '30.43', '2015-08-25', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (282, 17, '0', 10, '30.43', '2015-09-01', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (283, 17, '0', 11, '30.43', '2015-09-08', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (284, 17, '0', 12, '30.43', '2015-09-15', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (285, 17, '0', 13, '30.43', '2015-09-22', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (286, 17, '0', 14, '30.43', '2015-09-29', 0, 1, '2015-06-29 13:03:35', '2015-06-29 13:03:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (287, 18, '0', 1, '0', '2015-03-24', 1, 1, '2015-06-29 13:05:11', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (288, 18, '0', 2, '0', '2015-03-31', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (289, 18, '0', 3, '0', '2015-04-07', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (290, 18, '0', 4, '0', '2015-04-17', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (291, 18, '0', 5, '0', '2015-04-22', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (292, 18, '0', 6, '0', '2015-04-28', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (293, 18, '0', 7, '0', '2015-05-05', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (294, 18, '0', 8, '0', '2015-05-12', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (295, 18, '0', 9, '0', '2015-05-19', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (296, 18, '0', 10, '0', '2015-05-26', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (297, 18, '0', 11, '0', '2015-06-03', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:21:19');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (298, 18, '0', 12, '0', '2015-06-09', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:22:04');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (299, 18, '0', 13, '0', '2015-06-16', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:22:04');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (300, 18, '0', 14, '0', '2015-06-23', 1, 1, '2015-06-29 13:05:12', '2015-06-29 13:22:04');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (301, 18, '0', 15, '25', '2015-06-30', 0, 1, '2015-06-29 13:05:12', '2015-06-29 13:05:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (302, 18, '0', 16, '25', '2015-07-07', 0, 1, '2015-06-29 13:05:12', '2015-06-29 13:05:12');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (303, 19, '0', 1, '0', '2015-06-16', 1, 1, '2015-06-29 13:06:13', '2015-06-29 13:29:58');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (304, 19, '0', 2, '0', '2015-06-23', 1, 1, '2015-06-29 13:06:13', '2015-06-29 13:29:58');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (305, 19, '0', 3, '42.78', '2015-06-30', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (306, 19, '0', 4, '42.78', '2015-07-07', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (307, 19, '0', 5, '42.78', '2015-07-14', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (308, 19, '0', 6, '42.78', '2015-07-21', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (309, 19, '0', 7, '42.78', '2015-07-28', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (310, 19, '0', 8, '42.78', '2015-08-04', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (311, 19, '0', 9, '42.78', '2015-08-11', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (312, 19, '0', 10, '42.78', '2015-08-18', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (313, 19, '0', 11, '42.78', '2015-08-25', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (314, 19, '0', 12, '42.78', '2015-09-01', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (315, 19, '0', 13, '42.78', '2015-09-08', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (316, 19, '0', 14, '42.78', '2015-09-15', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (317, 19, '0', 15, '42.78', '2015-09-22', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (318, 19, '0', 16, '42.78', '2015-09-29', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (319, 19, '0', 17, '42.78', '2015-10-06', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (320, 19, '0', 18, '42.78', '2015-10-13', 0, 1, '2015-06-29 13:06:13', '2015-06-29 13:06:13');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (321, 20, '0', 1, '40', '2015-06-30', 0, 1, '2015-06-29 13:07:06', '2015-06-29 13:07:06');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (322, 20, '0', 2, '40', '2015-07-07', 0, 1, '2015-06-29 13:07:06', '2015-06-29 13:07:06');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (323, 20, '0', 3, '40', '2015-07-14', 0, 1, '2015-06-29 13:07:06', '2015-06-29 13:07:06');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (324, 20, '0', 4, '40', '2015-07-21', 0, 1, '2015-06-29 13:07:06', '2015-06-29 13:07:06');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (325, 20, '0', 5, '40', '2015-07-28', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (326, 20, '0', 6, '40', '2015-08-04', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (327, 20, '0', 7, '40', '2015-08-11', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (328, 20, '0', 8, '40', '2015-08-18', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (329, 20, '0', 9, '40', '2015-08-25', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (330, 20, '0', 10, '40', '2015-09-01', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (331, 20, '0', 11, '40', '2015-09-08', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (332, 20, '0', 12, '40', '2015-09-15', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (333, 20, '0', 13, '40', '2015-09-22', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (334, 20, '0', 14, '40', '2015-09-29', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (335, 20, '0', 15, '40', '2015-10-06', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (336, 20, '0', 16, '40', '2015-10-13', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (337, 20, '0', 17, '40', '2015-10-20', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (338, 20, '0', 18, '40', '2015-10-27', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (339, 20, '0', 19, '40', '2015-11-03', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (340, 20, '0', 20, '40', '2015-11-10', 0, 1, '2015-06-29 13:07:07', '2015-06-29 13:07:07');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (341, 21, '0', 1, '0', '2015-06-16', 1, 1, '2015-06-29 13:08:50', '2015-06-29 13:29:22');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (342, 21, '0', 2, '0', '2015-06-23', 1, 1, '2015-06-29 13:08:50', '2015-07-17 22:03:30');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (343, 21, '0', 3, '37', '2015-06-30', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (344, 21, '0', 4, '37', '2015-07-07', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (345, 21, '0', 5, '37', '2015-07-14', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (346, 21, '0', 6, '37', '2015-07-21', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (347, 21, '0', 7, '37', '2015-07-28', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (348, 21, '0', 8, '37', '2015-08-04', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (349, 21, '0', 9, '37', '2015-08-11', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (350, 21, '0', 10, '37', '2015-08-18', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (351, 21, '0', 11, '37', '2015-08-25', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (352, 21, '0', 12, '37', '2015-09-01', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (353, 21, '0', 13, '37', '2015-09-08', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (354, 21, '0', 14, '37', '2015-09-15', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (355, 21, '0', 15, '37', '2015-09-22', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (356, 21, '0', 16, '37', '2015-09-29', 0, 1, '2015-06-29 13:08:50', '2015-06-29 13:08:50');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (357, 22, '0', 1, '13', '2015-06-24', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (358, 22, '0', 2, '13', '2015-06-25', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (359, 22, '0', 3, '13', '2015-06-26', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (360, 22, '0', 4, '13', '2015-06-27', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (361, 22, '0', 5, '13', '2015-06-29', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (362, 22, '0', 6, '13', '2015-06-30', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (363, 22, '0', 7, '13', '2015-07-01', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (364, 22, '0', 8, '13', '2015-07-02', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (365, 22, '0', 9, '13', '2015-07-03', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (366, 22, '0', 10, '13', '2015-07-04', 0, 1, '2015-06-30 22:49:35', '2015-06-30 22:49:35');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (367, 23, '10', 1, '13', '2015-07-09', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (368, 23, '10', 2, '13', '2015-07-10', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (369, 23, '10', 3, '13', '2015-07-11', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (370, 23, '10', 4, '13', '2015-07-13', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (371, 23, '10', 5, '13', '2015-07-14', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (372, 23, '10', 6, '13', '2015-07-15', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (373, 23, '10', 7, '13', '2015-07-16', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (374, 23, '10', 8, '13', '2015-07-17', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (375, 23, '10', 9, '13', '2015-07-18', 0, 1, '2015-07-08 23:42:18', '2015-07-08 23:42:18');
INSERT INTO loan_schedule_payment_detail (`loan_schedule_payment_detail_id`, `using_loan_id`, `principle_paid_amount`, `times`, `payment_amount`, `payment_date`, `is_paid`, `status`, `created_date`, `modified_date`) VALUES (376, 23, '10', 10, '13', '2015-07-20', 0, 1, '2015-07-08 23:42:19', '2015-07-08 23:42:19');


#
# TABLE STRUCTURE FOR: loan_terms
#

DROP TABLE IF EXISTS loan_terms;

CREATE TABLE `loan_terms` (
  `loan_term_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`loan_term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO loan_terms (`loan_term_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (1, 'TERMS (Daily)', ' payment by daily', 1, '2015-03-17 23:25:32', '2015-03-17 23:25:36');
INSERT INTO loan_terms (`loan_term_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (2, 'TERMS (Weekly)', 'Payment by weekly', 1, '2015-04-05 08:33:41', NULL);
INSERT INTO loan_terms (`loan_term_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (3, 'TERMS (Two weekly)', 'Payment by two weekly', 1, '2015-04-05 08:35:18', NULL);
INSERT INTO loan_terms (`loan_term_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (4, 'TERMS (Three Weekly)', 'Pyament by three weekly', 1, '2015-04-05 08:36:35', NULL);
INSERT INTO loan_terms (`loan_term_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (5, 'TERMS(Monthly)', 'Payment by monthly', 1, '2015-04-05 08:36:22', '2015-04-05 00:00:00');


#
# TABLE STRUCTURE FOR: loan_types
#

DROP TABLE IF EXISTS loan_types;

CREATE TABLE `loan_types` (
  `loan_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `interest` float DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`loan_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO loan_types (`loan_type_id`, `name`, `description`, `interest`, `status`, `created_date`, `modified_date`) VALUES (1, 'flat', 'flate', '0.05', 1, '2015-06-28 21:23:26', '2015-03-17 21:28:31');
INSERT INTO loan_types (`loan_type_id`, `name`, `description`, `interest`, `status`, `created_date`, `modified_date`) VALUES (2, 'Decline', 'Decline', '1', 1, '2015-06-28 21:24:17', '2015-03-17 21:29:19');
INSERT INTO loan_types (`loan_type_id`, `name`, `description`, `interest`, `status`, `created_date`, `modified_date`) VALUES (3, 'Barloon', 'Baloon', '0.1', 1, '2015-06-28 21:24:54', '2015-03-17 21:50:52');


#
# TABLE STRUCTURE FOR: loans
#

DROP TABLE IF EXISTS loans;

CREATE TABLE `loans` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_no` varchar(45) DEFAULT NULL,
  `reference_no` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `requested_date` date DEFAULT NULL,
  `released_date` date NOT NULL,
  `closed_date` date NOT NULL,
  `notes` text,
  `purpose` text,
  `revision` int(11) NOT NULL,
  `number_interest` float NOT NULL,
  `deduction_start` date DEFAULT NULL,
  `cus_colleteral` text NOT NULL,
  `number_time_payment` int(11) NOT NULL,
  `using_employee_id` int(11) DEFAULT NULL,
  `using_loan_type_id` int(11) DEFAULT NULL,
  `using_loan_term_id` int(11) DEFAULT NULL,
  `using_interest_id` int(11) DEFAULT NULL,
  `using_customer_id` int(11) DEFAULT NULL,
  `using_insurance_id` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `loan_using_user_id_idx` (`using_employee_id`),
  KEY `loan_using_term_id_idx` (`using_loan_term_id`),
  KEY `loan_using_type_id_idx` (`using_loan_type_id`),
  KEY `loan_using_customer_id_idx` (`using_customer_id`),
  CONSTRAINT `loan_using_term_id` FOREIGN KEY (`using_loan_term_id`) REFERENCES `loan_terms` (`loan_term_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `loan_using_type_id` FOREIGN KEY (`using_loan_type_id`) REFERENCES `loan_types` (`loan_type_id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (4, 'GL0001', '8', '250', '2015-06-01', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-16', '', 14, 1, 1, 2, 1, 8, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (5, 'GL0005', '9', '300', '2015-06-01', '2015-06-29', '0000-00-00', '', 'car', 1, '3.1', '2015-05-26', '', 12, 1, 1, 2, 1, 9, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (6, 'GL0006', '10', '300', '2015-05-26', '2015-06-29', '0000-00-00', '', '', 1, '2.68', '2015-05-26', '', 10, 1, 1, 2, 1, 10, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (7, 'GL0007', '5', '200', '2015-04-26', '2015-06-29', '0000-00-00', '', '', 1, '3.5', '2015-05-19', '', 10, 1, 1, 2, 1, 5, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (8, 'GL0008', '4', '350', '2015-03-30', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-05-19', '', 14, 1, 1, 2, 1, 4, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (9, 'GL0009', '13', '50', '2015-05-04', '2015-06-29', '0000-00-00', '', '', 1, '4', '2015-06-16', '', 5, 1, 1, 2, 1, 13, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (10, 'GL00010', '12', '150', '2015-03-29', '2015-06-29', '0000-00-00', '', '', 1, '3.5', '2015-06-09', '', 12, 1, 1, 2, 1, 12, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (11, 'GL00011', '7', '200', '2015-03-30', '2015-06-29', '0000-00-00', '', '', 1, '0.4', '2015-06-19', '', 30, 1, 1, 1, 1, 7, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (12, 'GL00012', '2', '400', '2015-05-31', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-23', '', 8, 1, 1, 2, 1, 2, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (13, 'GL00013', '3', '400', '2015-03-30', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-23', '', 8, 1, 1, 2, 1, 3, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (14, 'GL00014', '15', '200', '2015-03-30', '2015-06-29', '0000-00-00', '', '', 1, '0.4', '2015-06-22', '', 40, 1, 1, 1, 1, 15, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (15, 'GL00015', '19', '200', '2015-04-07', '2015-06-29', '0000-00-00', '', '', 1, '3.1', '2015-06-09', '', 16, 1, 1, 2, 1, 19, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (16, 'GL00016', '18', '350', '2015-03-31', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-09', '', 18, 1, 1, 2, 1, 18, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (17, 'GL00017', '20', '300', '2015-04-06', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-23', '', 14, 1, 1, 2, 1, 20, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (18, 'GL00018', '11', '250', '2014-12-29', '2015-06-29', '0000-00-00', '', '', 1, '3.75', '2015-03-17', '', 16, 1, 1, 2, 1, 11, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (19, 'GL00019', '14', '500', '2015-04-07', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-09', '', 18, 1, 1, 2, 1, 14, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (20, 'GL00020', '16', '500', '2015-02-22', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-23', '', 20, 1, 1, 2, 1, 16, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (21, 'GL00021', '6', '400', '2015-06-07', '2015-06-29', '0000-00-00', '', '', 1, '3', '2015-06-09', '', 16, 1, 1, 2, 1, 6, 1, 'released');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (22, 'GL00022', '2', '100', '2015-06-23', '0000-00-00', '0000-00-00', 'dd', 'us', 1, '3', '2015-06-23', 'dfd', 10, 1, 1, 1, 1, 1, 1, 'Pending');
INSERT INTO loans (`loan_id`, `trans_no`, `reference_no`, `amount`, `requested_date`, `released_date`, `closed_date`, `notes`, `purpose`, `revision`, `number_interest`, `deduction_start`, `cus_colleteral`, `number_time_payment`, `using_employee_id`, `using_loan_type_id`, `using_loan_term_id`, `using_interest_id`, `using_customer_id`, `using_insurance_id`, `status`) VALUES (23, 'GL00023', '2', '100', '2015-07-08', '0000-00-00', '0000-00-00', '', '', 2, '3', '2015-07-08', '', 10, 1, 1, 1, 1, 2, 1, 'Pending');


#
# TABLE STRUCTURE FOR: locations
#

DROP TABLE IF EXISTS locations;

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO locations (`location_id`, `name`, `status`, `created_date`, `modified_date`) VALUES (1, 'Phnom Penh', 1, '2015-03-16 22:07:21', '2015-03-16 22:07:25');
INSERT INTO locations (`location_id`, `name`, `status`, `created_date`, `modified_date`) VALUES (2, 'Kandal', 1, '2015-03-16 22:07:41', '2015-03-16 22:07:44');
INSERT INTO locations (`location_id`, `name`, `status`, `created_date`, `modified_date`) VALUES (3, 'Takeo', 1, '2015-03-16 22:11:50', '2015-03-16 22:11:46');


#
# TABLE STRUCTURE FOR: permissions
#

DROP TABLE IF EXISTS permissions;

CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (1, 'Users', 'Manager all user ', 1, '2015-03-14 17:18:41', '2015-03-14 17:18:46');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (2, 'Customers', 'Manage all customers', 1, '2015-03-14 17:23:26', '2015-03-14 17:23:30');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (3, 'Employees', 'Manage employees', 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (4, 'Insurances', 'Manage insurance', 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (5, 'Customer Collecteral', NULL, 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (6, 'My Loan', NULL, 1, '2015-04-08 18:38:12', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (7, 'Payment Loans', NULL, 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (8, 'Loan Management', NULL, 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (9, 'HR', NULL, 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');
INSERT INTO permissions (`permission_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (10, 'Reports', NULL, 1, '2015-04-08 00:00:00', '2015-04-08 00:00:00');


#
# TABLE STRUCTURE FOR: role_permissions
#

DROP TABLE IF EXISTS role_permissions;

CREATE TABLE `role_permissions` (
  `role_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_role_id` int(11) DEFAULT NULL,
  `using_permission_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_permission_id`),
  KEY `role_permission_use_role_id_idx` (`using_role_id`),
  KEY `role_permission_use_permission_id_idx` (`using_permission_id`),
  CONSTRAINT `role_permission_use_permission_id` FOREIGN KEY (`using_permission_id`) REFERENCES `permissions` (`permission_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permission_use_role_id` FOREIGN KEY (`using_role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (1, 1, 1, 1, '2015-03-14 17:26:35', '2015-03-14 17:26:39');
INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (2, 1, 2, 1, '2015-03-14 17:27:07', '2015-03-14 17:27:11');
INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (3, 2, 2, 1, '2015-03-14 17:27:47', '2015-03-14 17:27:50');
INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (7, 4, 3, 1, '2015-04-08 19:05:13', '2015-04-08 19:05:13');
INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (8, 4, 8, 1, '2015-04-08 19:05:13', '2015-04-08 19:05:13');
INSERT INTO role_permissions (`role_permission_id`, `using_role_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (9, 4, 9, 1, '2015-04-08 19:05:14', '2015-04-08 19:05:14');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS roles;

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO roles (`role_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (1, 'Admin', 'super access ', 1, '2015-03-14 17:17:22', '2015-03-14 17:17:28');
INSERT INTO roles (`role_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (2, 'Sub admin', 'access all accepted user', 1, '2015-03-14 17:22:14', '2015-03-14 17:22:17');
INSERT INTO roles (`role_id`, `name`, `description`, `status`, `created_date`, `modified_date`) VALUES (4, 'Human Resource', 'This is role hr update', 1, '2015-04-08 19:05:13', '2015-04-08 19:05:13');


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS setting;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(45) NOT NULL,
  `value` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (1, 'company_name', 'VBCA', 1, '2015-03-28 05:08:00', '2015-06-29 11:00:22');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (2, 'logo', 'Ratanaka_Realty.jpg', 1, '2015-03-28 00:00:00', '2015-06-30 19:48:00');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (3, 'phone', '0125917370', 1, '2015-03-28 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (4, 'email', 'info@jobpendings.com', 1, '2015-03-28 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (5, 'address', 'Phnom Penh, Cambodias', 1, '2015-03-28 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (6, 'fax', '0158392210', 1, '2015-04-05 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (7, 'timezone', 'America/New_York', 1, '2015-04-05 00:00:00', '2015-04-05 12:25:45');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (8, 'website', 'jobpendings.com', 1, '2015-04-05 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (9, 'currency', '4100', 1, '2015-04-05 00:00:00', '2015-04-05 13:06:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (10, 'language', 'english', 1, '2015-04-05 00:00:00', '2015-04-05 12:24:22');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (11, 'schedule_note', 'Thank you for choosing our products and service. We believe you will be satisfied by our services.', 1, '2015-05-22 23:06:27', '2015-05-22 23:06:35');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (12, 'prefix_employee', 'CLV-', 1, '0000-00-00 00:00:00', '2015-05-22 23:06:10');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (13, 'prefix_customer', 'CUS-', 1, '0000-00-00 00:00:00', '2015-05-22 23:06:12');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (14, 'Monday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-09 22:08:53');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (15, 'Tuesday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-09 22:08:49');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (16, 'Wednesday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-09 22:08:46');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (17, 'Thursday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-03 23:59:58');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (18, 'Friday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-03 23:59:58');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (19, 'Saturday', 'NO', 1, '0000-00-00 00:00:00', '2015-06-19 18:24:40');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (20, 'Sunday', 'YES', 1, '0000-00-00 00:00:00', '2015-06-09 22:09:00');
INSERT INTO setting (`setting_id`, `key`, `value`, `status`, `created_date`, `modified_date`) VALUES (21, 'prefix_insurance', 'INS-', 1, '0000-00-00 00:00:00', '2015-05-22 23:05:55');


#
# TABLE STRUCTURE FOR: user_permissions
#

DROP TABLE IF EXISTS user_permissions;

CREATE TABLE `user_permissions` (
  `user_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_user_id` int(11) DEFAULT NULL,
  `using_permission_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_permission_id`),
  KEY `user_permission_use_user_id_idx` (`using_user_id`),
  KEY `user_permission_use_permission_id_idx` (`using_permission_id`),
  CONSTRAINT `user_permission_use_permission_id` FOREIGN KEY (`using_permission_id`) REFERENCES `permissions` (`permission_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_permission_use_user_id` FOREIGN KEY (`using_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO user_permissions (`user_permission_id`, `using_user_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (1, 1, 1, 1, '2015-03-14 17:28:14', '2015-03-14 17:28:17');
INSERT INTO user_permissions (`user_permission_id`, `using_user_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (2, 1, 2, 1, '2015-03-14 17:28:42', '2015-03-14 17:28:45');
INSERT INTO user_permissions (`user_permission_id`, `using_user_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (3, 2, 2, 1, '2015-03-14 17:29:14', '2015-03-14 17:29:18');
INSERT INTO user_permissions (`user_permission_id`, `using_user_id`, `using_permission_id`, `status`, `created_date`, `modified_date`) VALUES (4, 3, 2, 1, '2015-03-14 17:29:56', '2015-03-14 17:29:59');


#
# TABLE STRUCTURE FOR: user_roles
#

DROP TABLE IF EXISTS user_roles;

CREATE TABLE `user_roles` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `using_user_id` int(11) DEFAULT NULL,
  `using_role_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_role_id`),
  KEY `user_role_using_user_id_idx` (`using_user_id`),
  KEY `user_role_using_role_id_idx` (`using_role_id`),
  CONSTRAINT `user_role_using_role_id` FOREIGN KEY (`using_role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_role_using_user_id` FOREIGN KEY (`using_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO user_roles (`user_role_id`, `using_user_id`, `using_role_id`, `status`, `created_date`, `modified_date`) VALUES (1, 1, 1, 1, '2015-03-14 17:24:15', '2015-03-14 17:24:17');
INSERT INTO user_roles (`user_role_id`, `using_user_id`, `using_role_id`, `status`, `created_date`, `modified_date`) VALUES (2, 2, 2, 1, '2015-03-14 17:25:06', '2015-03-14 17:25:12');
INSERT INTO user_roles (`user_role_id`, `using_user_id`, `using_role_id`, `status`, `created_date`, `modified_date`) VALUES (3, 3, 2, 1, '2015-03-14 17:25:42', '2015-03-14 17:25:45');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username_kh` varchar(75) DEFAULT NULL,
  `username_en` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(35) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `address` text,
  `using_location_id` int(11) DEFAULT NULL,
  `using_department_id` int(11) DEFAULT NULL,
  `profile_picture` varchar(125) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO users (`user_id`, `username_kh`, `username_en`, `email`, `mobile`, `phone`, `address`, `using_location_id`, `using_department_id`, `profile_picture`, `password`, `status`, `created_date`, `modified_date`) VALUES (1, 'វ៉ាន់ ជីវ័ន្ត', 'chivorn.vann', 'chivorn.vann007@gmail.com', '098 480860', '015591737', 'Phnom Penh, Cambodia', 1, 1, NULL, '7c222fb2927d828af22f592134e8932480637c0d', 1, '2015-03-19 20:00:26', '2015-05-12 22:14:47');
INSERT INTO users (`user_id`, `username_kh`, `username_en`, `email`, `mobile`, `phone`, `address`, `using_location_id`, `using_department_id`, `profile_picture`, `password`, `status`, `created_date`, `modified_date`) VALUES (2, 'ម៉ាណាឌី', 'manady.vann', 'manady.vann@gmail.com', '+85598272882', '0976834197', 'kandl', 2, 0, NULL, '042f6520e3e91b9ba2e92dbc5ddbe70699dbece3', 0, '2015-04-01 23:03:33', '2015-03-14 17:19:39');
INSERT INTO users (`user_id`, `username_kh`, `username_en`, `email`, `mobile`, `phone`, `address`, `using_location_id`, `using_department_id`, `profile_picture`, `password`, `status`, `created_date`, `modified_date`) VALUES (3, NULL, 'sokry.sat', 'sokry.sat@gmail.com', NULL, NULL, NULL, 1, 1, NULL, '1234567', 0, '2015-03-14 17:20:18', '2015-05-12 22:14:13');
INSERT INTO users (`user_id`, `username_kh`, `username_en`, `email`, `mobile`, `phone`, `address`, `using_location_id`, `using_department_id`, `profile_picture`, `password`, `status`, `created_date`, `modified_date`) VALUES (5, 'ផូ សុនី', 'Pho Sony', 'sony@gmail.com', '', '011557314 / 098666376', 'Kandal Province,Cambodia', 2, 0, '', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 1, '2015-03-16 23:15:14', '2015-04-08 18:40:42');


